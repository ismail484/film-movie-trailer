
import webbrowser

class Video():

    def __init__(self,title,duration):
        
        self.title=title
        self.duration=duration

    def show_trailer(self):
        print(self.title)
    

